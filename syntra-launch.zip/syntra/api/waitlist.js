// api/waitlist.js
// Vercel Serverless Function — handles waitlist email submissions
// Stores entries in /tmp/waitlist.json (ephemeral) and optionally sends
// a confirmation email via Resend (https://resend.com — free tier: 3k emails/mo)

import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join } from 'path';

const DB_PATH = '/tmp/syntra_waitlist.json';
const RESEND_API_KEY = process.env.RESEND_API_KEY;    // set in Vercel env vars
const FROM_EMAIL    = process.env.FROM_EMAIL || 'waitlist@syntra.ai';
const NOTIFY_EMAIL  = process.env.NOTIFY_EMAIL;       // your email to get pinged on each signup

// ─── helpers ───────────────────────────────────────────────────────────────

function loadDB() {
  if (!existsSync(DB_PATH)) return { emails: [], count: 0 };
  try { return JSON.parse(readFileSync(DB_PATH, 'utf8')); }
  catch { return { emails: [], count: 0 }; }
}

function saveDB(db) {
  writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

async function sendEmail({ to, subject, html }) {
  if (!RESEND_API_KEY) return { skipped: true };
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${RESEND_API_KEY}`,
    },
    body: JSON.stringify({ from: FROM_EMAIL, to, subject, html }),
  });
  return res.json();
}

// ─── confirmation email HTML ────────────────────────────────────────────────

function confirmationEmail(email) {
  return `<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width"/></head>
<body style="margin:0;padding:0;background:#0a0a08;font-family:monospace">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#0a0a08;padding:48px 0">
<tr><td align="center">
<table width="540" cellpadding="0" cellspacing="0" style="background:#111110;border:1px solid #232320;border-radius:8px;overflow:hidden;max-width:540px;width:100%">
  <tr><td style="background:#c8f135;padding:20px 40px">
    <span style="font-family:sans-serif;font-weight:900;font-size:22px;letter-spacing:-0.03em;color:#0a0a08">Syntr<span style="color:#0a0a08">a</span></span>
  </td></tr>
  <tr><td style="padding:48px 40px">
    <p style="color:#c8f135;font-size:11px;letter-spacing:0.2em;text-transform:uppercase;margin:0 0 24px">// You're on the list</p>
    <h1 style="font-family:sans-serif;font-size:32px;font-weight:900;letter-spacing:-0.03em;color:#f0ede6;margin:0 0 20px;line-height:1.1">Welcome to Syntра. <br/>Big things incoming.</h1>
    <p style="color:#7a7870;font-size:14px;line-height:1.75;margin:0 0 32px">You're officially on the early access waitlist. Here's what happens next:</p>
    <table width="100%" cellpadding="0" cellspacing="0">
      <tr><td style="padding:14px 18px;background:#161614;border:1px solid #232320;border-radius:6px;margin-bottom:10px;display:block">
        <span style="color:#c8f135;margin-right:10px">→</span><span style="color:#f0ede6;font-size:13px">We're reviewing waitlist requests and will send your invite within 1–2 weeks</span>
      </td></tr>
      <tr><td style="height:10px"></td></tr>
      <tr><td style="padding:14px 18px;background:#161614;border:1px solid #232320;border-radius:6px">
        <span style="color:#c8f135;margin-right:10px">→</span><span style="color:#f0ede6;font-size:13px">Early access members lock in <strong style="color:#c8f135">40% off</strong> forever — no catches</span>
      </td></tr>
      <tr><td style="height:10px"></td></tr>
      <tr><td style="padding:14px 18px;background:#161614;border:1px solid #232320;border-radius:6px">
        <span style="color:#c8f135;margin-right:10px">→</span><span style="color:#f0ede6;font-size:13px">Priority onboarding with direct access to our founding team</span>
      </td></tr>
    </table>
    <div style="margin-top:40px;padding-top:32px;border-top:1px solid #232320">
      <p style="color:#555450;font-size:12px;margin:0">Signed up as <span style="color:#7a7870">${email}</span>. Reply to this email with any questions.</p>
    </div>
  </td></tr>
</table>
</td></tr>
</table>
</body>
</html>`;
}

// ─── handler ────────────────────────────────────────────────────────────────

export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { email, source = 'unknown' } = req.body || {};

  if (!email || !isValidEmail(email)) {
    return res.status(400).json({ error: 'Invalid email address' });
  }

  const db = loadDB();

  // Duplicate check
  if (db.emails.some(e => e.email === email.toLowerCase())) {
    return res.status(409).json({ error: 'Already on the waitlist!' });
  }

  // Save entry
  db.emails.push({
    email: email.toLowerCase(),
    source,
    ip: req.headers['x-forwarded-for'] || req.socket?.remoteAddress || 'unknown',
    timestamp: new Date().toISOString(),
    position: db.emails.length + 1,
  });
  db.count = db.emails.length;
  saveDB(db);

  // Fire emails in parallel (don't block response on email)
  const emailPromises = [
    sendEmail({
      to: email,
      subject: "You're on the Syntра waitlist 🎉",
      html: confirmationEmail(email),
    }),
  ];

  if (NOTIFY_EMAIL) {
    emailPromises.push(sendEmail({
      to: NOTIFY_EMAIL,
      subject: `New waitlist signup: ${email}`,
      html: `<p>New signup from <b>${email}</b> (source: ${source}). Total: <b>${db.count}</b></p>`,
    }));
  }

  // Don't await — respond immediately, emails send async
  Promise.all(emailPromises).catch(console.error);

  return res.status(200).json({
    success: true,
    position: db.count,
    message: "You're on the list!",
  });
}
